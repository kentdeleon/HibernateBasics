package com.infiniteskills.data;

import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infiniteskills.data.entities.User;

public class Application {

	public static void main(String[] args) {
		Logger LOGGER = Logger.getLogger(Application.class);
		SessionFactory sessionFactory = null;
		Session session = null;
		org.hibernate.Transaction tx = null;
		
		try {
		
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			User user = new User();
			user.setFirstName("Kent Louis");
			user.setLastName("De Leon");
			user.setBirthDate(new Date());
			user.setCreateDate(new Date());
			user.setCreatedBy("Kent De Leon");
			user.setLastUpdatedDate(new Date());
			user.setLastUpdatedBy("Kent De Leon");
			user.setEmailAddress("kent.deleon@email.com");
			
			LOGGER.info("is user exist? " + session.contains(user));
			
			session.save(user);
			
			tx.commit();
			
			LOGGER.info("is user exist? " + session.contains(user));
		}catch(Exception e) {
			e.printStackTrace();
			tx.rollback();
		}finally {
			session.close();
			sessionFactory.close();
		}
	}

}
