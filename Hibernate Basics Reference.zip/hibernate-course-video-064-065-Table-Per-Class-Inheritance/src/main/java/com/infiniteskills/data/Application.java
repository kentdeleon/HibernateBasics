package com.infiniteskills.data;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.entities.Bond;
import com.infiniteskills.data.entities.Investment;
import com.infiniteskills.data.entities.Portfolio;
import com.infiniteskills.data.entities.Stock;

public class Application {

	public static void main(String[] args) {

		Logger LOGGER = LoggerFactory.getLogger(Application.class);
		ApplicationUtil.runDemoForTablePerClassInheritance(LOGGER);
	}

}
