package com.infiniteskills.data;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.entities.Address;
import com.infiniteskills.data.entities.Bank;
import com.infiniteskills.data.entities.Currency;
import com.infiniteskills.data.entities.Ids.CurrencyId;

public class Application {

	public static void main(String[] args) {

		SessionFactory sessionFactory = null;
		Session session = null;
		Session session2 = null;
		org.hibernate.Transaction tx = null;
		org.hibernate.Transaction tx2 = null;
		
		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			Currency currency = new Currency();
			currency.setCountryName("Philippines");
			currency.setName("Pesos");
			currency.setSymbol("P");
			
			session.persist(currency);
			tx.commit();
			
			session2 = sessionFactory.openSession();
			tx2 = session2.beginTransaction();
			
			//retrieve entity
			Currency dbCurrency = (Currency) session2.get(Currency.class, new CurrencyId("Dollar", "United States"));
			System.out.println(dbCurrency.getName());
			tx2.commit();
		}catch(Exception e) {
			e.printStackTrace();
			tx.rollback();
			if(tx2 != null) {
				tx2.rollback();
			}
		}finally {
			session.close();
			sessionFactory.close();
		}
	}

}
