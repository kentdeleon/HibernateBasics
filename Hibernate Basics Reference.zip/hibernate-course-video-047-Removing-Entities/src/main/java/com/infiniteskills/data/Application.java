package com.infiniteskills.data;


import java.util.Date;

import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.entities.Bank;


public class Application {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Logger LOGGER = LoggerFactory.getLogger(Application.class);
		
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();
			
			Bank bank = (Bank) session.get(Bank.class, 1L);
			LOGGER.info("is bank entities still exists? " + session.contains(bank));
			
			//invoke  delete method on the session  to delete the entity
			session.delete(bank);
			
			LOGGER.info("Method Delete Invoked!");
			LOGGER.info("is bank entities still exists? " + session.contains(bank));
			
			transaction.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	
	
	

}
