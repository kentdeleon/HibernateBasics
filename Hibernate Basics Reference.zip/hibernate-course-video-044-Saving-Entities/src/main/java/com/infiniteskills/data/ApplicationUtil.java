package com.infiniteskills.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;

import com.infiniteskills.data.entities.Account;
import com.infiniteskills.data.entities.Address;
import com.infiniteskills.data.entities.Transaction;
import com.infiniteskills.data.entities.User;

public class ApplicationUtil {

	public final static void runDemoForBiDirectionalManyToMany040(Session session) {
		
		try {
		org.hibernate.Transaction transaction = session.beginTransaction();
		
		//creating accounts
		Account octalAccount = ApplicationUtil.createNewAccount("BiDirecitonal Many Many Checking Account", "Checking Account", new BigDecimal(15000.00), new BigDecimal(15000.00), new Date(), new Date(), "Kent De Leon", new Date(), new Date(), "Kent de Leon");
		Account pccwAccount = ApplicationUtil.createNewAccount("BiDirecitonal Many Many Savings Account", "Savings Account", new BigDecimal(15000.00), new BigDecimal(15000.00), new Date(), new Date(), "Kent De Leon", new Date(), new Date(), "Kent de Leon");
		
		//creating address for users
		List<Address> addresses = new ArrayList<>();
		addresses.add(ApplicationUtil.createAddress("Quezon City Timog Ave", "Scout Lozano", "Quezon City", "QC", "12345"));
		
		//creating users and setting the address
		User user = ApplicationUtil.createUser("BiDirectional", "ManyToManyOne", new Date(), "first.name@email.com", new Date(), "Kent De Leon", new Date(), "Kent De leon");
		user.setAddress(addresses);
		User user2 = ApplicationUtil.createUser("BiDirectional", "ManyToManyTwo", new Date(), "two.name@email.com", new Date(), "Kent De Leon", new Date(), "Kent De leon");
		user2.setAddress(addresses);
		
		//creating user set and setting the user set to each accounts
		Set<User> userSet = new HashSet<>();
		userSet.add(user);
		userSet.add(user2);
		octalAccount.setUsers(userSet);
		pccwAccount.setUsers(userSet);
		
		//creating account set and setting the account set to each users
		//saving the accounts
		Set<Account> accountSet = new HashSet<>();
		accountSet.add(octalAccount);
		accountSet.add(pccwAccount);
		user.setAccounts(accountSet);
		user2.setAccounts(accountSet);
		
		session.save(octalAccount);
		session.save(pccwAccount);
		
		session.save(user);
		session.save(user2);
		
		transaction.commit();
	
		//verifying the account was added
		Account dbAccount = (Account) session.get(Account.class, octalAccount.getAccountId());
		System.out.println("dbAccount: " + dbAccount.getUsers().iterator().next().getEmailAddress());
		
		User userDb = (User) session.get(User.class, user.getUserId());
		System.out.println("userDb: " + userDb.getAccounts().iterator().next().getName());
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	public final static Address createAddress(String addressLine1, String addressLine2, String city, String state, String zipCode) {
		return Address.createAddress(addressLine1, addressLine2, city, state, zipCode);
	}
	public final static User createUser(String firstName, String lastName, Date birthDate, String emailAddress, Date lastUpdatedDate, String lastUpdatedBy, Date createDate, String createdBy) {
		return User.createUser(firstName, lastName, birthDate, emailAddress, lastUpdatedDate, lastUpdatedBy, createDate, createdBy);
	}
	public final static Account createNewAccount(String name, String accountType, BigDecimal initialBalance, BigDecimal currentBalance, Date openDate,
			Date closeDate, String lastUpdatedBy, Date lastUpdatedDate, Date createdDate, String createdBy) {
		Account account = Account.createAccount(name, accountType, initialBalance,
				currentBalance, openDate, closeDate, lastUpdatedBy, lastUpdatedDate, createdDate, createdBy);
		return account;
	}
	
	public final static Transaction addSingleTransaction(String transactionType, String title, BigDecimal amount, BigDecimal initialBalance,
			BigDecimal closingBalance, String notes, String lastUpdatedBy, Date lastUpdatedDate, String createdBy,
			Date createdDate, Account account) {
		return Transaction.createSingleTransaction(transactionType, title, amount, initialBalance, closingBalance, notes, lastUpdatedBy, lastUpdatedDate, createdBy, createdDate, account);
	}
	
	public final static List<Transaction> addTransactions(Account account) {
		List<Transaction> transactions = new ArrayList<>();
		
		Transaction transactions1 = new Transaction();
		transactions1.setTitle("13th Month Pay");
		transactions1.setAmount(new BigDecimal(500.00));
		transactions1.setClosingBalance(new BigDecimal(0.00));
		transactions1.setCreatedBy("Kent De Leon");
		transactions1.setCreatedDate(new Date());
		transactions1.setInitialBalance(new BigDecimal(0.00));
		transactions1.setTransactionType("Deposit");
		transactions1.setLastUpdatedBy("Kent De Leon");
		transactions1.setLastUpdatedDate(new Date());
		transactions1.setNotes("Depositing 13th Month Pay");
		transactions1.setAccount(account);
		
		Transaction transactions2 = new Transaction();
		transactions2.setTitle("Purchase Shoes");
		transactions2.setAmount(new BigDecimal(50.00));
		transactions2.setClosingBalance(new BigDecimal(0.00));
		transactions2.setCreatedBy("Kent De Leon");
		transactions2.setCreatedDate(new Date());
		transactions2.setInitialBalance(new BigDecimal(0.00));
		transactions2.setTransactionType("Debit");
		transactions2.setLastUpdatedBy("Kent De Leon");
		transactions2.setLastUpdatedDate(new Date());
		transactions2.setNotes("Purchase Shoes");
		transactions2.setAccount(account);
		
		
		transactions.add(transactions1);
		transactions.add(transactions2);
		
		return transactions;
		

	}
}
