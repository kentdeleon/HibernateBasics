package com.infiniteskills.data;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.infiniteskills.data.entities.Account;
import com.infiniteskills.data.entities.Transaction;


public class Application {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Account account = ApplicationUtil.createNewAccount("Saving Entities Account", "Savings", new BigDecimal(1500.00), 
				new BigDecimal(1500.00), new Date(), new Date(), "Kent De Leon", new Date(), new Date(), "Kent De Leon");
		Transaction transaction1 = ApplicationUtil.addSingleTransaction("Deposit", "Deposit 100.00", new BigDecimal(100.00), new BigDecimal(0.00),
				new BigDecimal(0.00), "Deposit 100.00", "Kent De Leon", new Date(), "Kent De Leon", new Date(), account);
		
		Transaction transaction2 = ApplicationUtil.addSingleTransaction("Withdraw", "Withdraw 100.00", new BigDecimal(100.00), new BigDecimal(0.00),
				new BigDecimal(0.00), "Withdraw 100.00", "Kent De Leon", new Date(), "Kent De Leon", new Date(), account);
		
		//transient state
		System.out.println("account: " + session.contains(account));
		System.out.println("transactions1: " + session.contains(transaction1));
		System.out.println("transaction2: " + session.contains(transaction2));
		
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();	
			session.save(transaction1);
			session.save(transaction2);
			
			//persistent state
			System.out.println("account: " + session.contains(account));
			System.out.println("transactions1: " + session.contains(transaction1));
			System.out.println("transaction2: " + session.contains(transaction2));
			
			transaction.commit();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	
	
	

}
