package com.infiniteskills.data.dao;

import java.util.List;

import org.hibernate.Session;

import com.infiniteskills.data.dao.interfaces.UserDao;
import com.infiniteskills.data.entities.User;

public class UserHibernateDao extends AbstractDao<User, Long> implements UserDao {

	@Override
	public List<User> findByFirstName(String firstName) {
		// TODO Auto-generated method stub
		return null;
	} 

}
