package com.infiniteskills.data;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.dao.UserHibernateDao;
import com.infiniteskills.data.dao.interfaces.UserDao;
import com.infiniteskills.data.entities.User;

public class Application {

	public static void main(String[] args) {

		Logger LOGGER = LoggerFactory.getLogger(Application.class);
		ApplicationUtil.runDemoPersistenceLayer(LOGGER);
	}

}
