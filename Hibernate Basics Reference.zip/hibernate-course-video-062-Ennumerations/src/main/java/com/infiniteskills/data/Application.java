package com.infiniteskills.data;

import java.math.BigDecimal;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.entities.Account;
import com.infiniteskills.data.entities.AccountType;
import com.infiniteskills.data.entities.Currency;
import com.infiniteskills.data.entities.Market;

public class Application {

	public static void main(String[] args) {

		Logger LOGGER = LoggerFactory.getLogger(Application.class);
		ApplicationUtil.runDemoeForEnumeration(LOGGER);
	}

}
