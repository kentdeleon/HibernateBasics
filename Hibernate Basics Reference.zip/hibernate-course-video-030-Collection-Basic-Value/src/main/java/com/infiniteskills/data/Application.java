package com.infiniteskills.data;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.infiniteskills.data.entities.Address;
import com.infiniteskills.data.entities.Bank;

public class Application {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		try {
			Transaction transaction = session.beginTransaction();	
			
			Bank bank = new Bank();
			bank.setName("Federal Trust TWO");
			bank.setCreatedBy("Kent De Leon");
			bank.setCreatedDate(new Date());
			bank.setLastUpdatedBy("Kent De Leon");
			bank.setLastUpdatedDate(new Date());
			bank.setInternational(false);
			
			Map<String,String> contacts = new HashMap<>();
			contacts.put("MANAGER", "Joe");
			contacts.put("GUARD", "Harry");
			contacts.put("TELLER", "Mary");
			bank.setContacts(contacts);
//			
//			User user = new User();
//			user.setFirstName("Kevin");
//			user.setLastName("BowerSox");
//			user.setCreateDate(new Date());
//			user.setCreatedBy("Kent De leon");
//			user.setCreateDate(new Date());
//			user.setLastUpdatedBy("Kent De Leon");
//			user.setLastUpdatedDate(new Date());
//			user.setBirthDate(new Date());
//			user.setAge(22);
//			user.setEmailAddress("bowersox@email.com");
			
			Address address = new Address();
			address.setAddressLine1("Line 1");
			address.setAddressLine2("Line 2");
			address.setCity("Philadelphia");
			address.setState("PA");
			address.setZipCode("12345");
			
			bank.setAddress(address);
			
			session.save(bank);
			
			transaction.commit();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	
	private static Date getMyBirthday() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 1984);
		calendar.set(Calendar.MONTH, 6);
		calendar.set(Calendar.DATE, 19);
		return calendar.getTime();
	}

}
