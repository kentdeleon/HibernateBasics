package com.infiniteskills.data;


import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.entities.Bank;


public class Application {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Logger LOGGER = LoggerFactory.getLogger(Application.class);
		
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();
			
			//get method - also reference Object cache in persisting context
//			Bank bank = (Bank) session.get(Bank.class, 1L);
//			bank = (Bank) session.get(Bank.class, 1L);
			
			//load method - hibernate always attempts to return a proxy
			//Once we need to reference something it is only the time the Database operation will be executed
			Bank bankLoad = (Bank) session.load(Bank.class, 1L);
			
			LOGGER.info("Method Executed");
			
			System.out.println(bankLoad.getName());
			transaction.commit();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	
	
	

}
