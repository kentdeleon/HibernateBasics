package com.infiniteskills.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;


import com.infiniteskills.data.entities.Account;
import com.infiniteskills.data.entities.Transaction;

public class Application {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();	
			
			Account account = createNewAccount();
			account.setTransaction(addTransaction());
			session.save(account);
			transaction.commit();
			
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	
	private static Date getMyBirthday() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.YEAR, 1984);
		calendar.set(Calendar.MONTH, 6);
		calendar.set(Calendar.DATE, 19);
		return calendar.getTime();
	}
	
	private static Account createNewAccount() {
		Account account = new Account();
		account.setName("IBM Savings Account");
		account.setInitialBalance(new BigDecimal(150));
		account.setCurrentBalance(new BigDecimal(150));
		account.setOpenDate(new Date());
		account.setCloseDate(new Date());
		account.setCreatedBy("Kent De Leon");
		account.setCreatedDate(new Date());
		account.setLastUpdatedBy("Kent De Leon");
		account.setLastUpdatedDate(new Date());
		
		
		return account;
	}
	
	private static List<Transaction> addTransaction() {
		List<Transaction> transactions = new ArrayList<>();
		
		Transaction transactions1 = new Transaction();
		transactions1.setTitle("13th Month Pay");
		transactions1.setAmount(new BigDecimal(500.00));
		transactions1.setClosingBalance(new BigDecimal(0.00));
		transactions1.setCreatedBy("Kent De Leon");
		transactions1.setCreatedDate(new Date());
		transactions1.setInitialBalance(new BigDecimal(0.00));
		transactions1.setTransactionType("Deposit");
		transactions1.setLastUpdatedBy("Kent De Leon");
		transactions1.setLastUpdatedDate(new Date());
		transactions1.setNotes("Depositing 13th Month Pay");
		
		Transaction transactions2 = new Transaction();
		transactions2.setTitle("Purchase Shoes");
		transactions2.setAmount(new BigDecimal(50.00));
		transactions2.setClosingBalance(new BigDecimal(0.00));
		transactions2.setCreatedBy("Kent De Leon");
		transactions2.setCreatedDate(new Date());
		transactions2.setInitialBalance(new BigDecimal(0.00));
		transactions2.setTransactionType("Debit");
		transactions2.setLastUpdatedBy("Kent De Leon");
		transactions2.setLastUpdatedDate(new Date());
		transactions2.setNotes("Purchase Shoes");
		
		
		transactions.add(transactions1);
		transactions.add(transactions2);
		
		return transactions;
		

	}

}
