package com.infiniteskills.data;

import java.util.Date;

import org.hibernate.Session;

import com.infiniteskills.data.entities.User;

public class Application {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.getTransaction().begin();
		
//		User user = new User();
//		user.setBirthDate(new Date());
//		user.setCreateDate(new Date());
//		user.setCreatedBy("Lorem");
//		user.setEmailAddress("lorem.ipsum@email.com");
//		user.setFirstName("Lorem");
//		user.setLastName("Ipsum");
//		user.setLastUpdatedBy("kent");
//		user.setLastUpdatedDate(new Date());
//		session.save(user);
		
		User user = (User) session.load(User.class, 2L);
		
		user.setFirstName("Updated First Name");
		user.setCreateDate(new Date());
		user.setCreatedBy("Updated By");
		
		session.getTransaction().commit();
		session.close();
	}

}
