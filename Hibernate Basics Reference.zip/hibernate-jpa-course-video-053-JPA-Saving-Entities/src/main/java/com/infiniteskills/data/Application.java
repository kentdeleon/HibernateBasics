package com.infiniteskills.data;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;



import com.infiniteskills.data.entities.Bank;

public class Application {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = null;
		EntityManager entityManager = null;
		EntityTransaction entityTransaction = null;
		
		try {
			factory = Persistence.createEntityManagerFactory("infinite-finances");
			entityManager  = factory.createEntityManager();
			entityTransaction = entityManager.getTransaction();
			entityTransaction.begin();
			
			Bank bank = ApplicationUtil.createBank();
			entityManager.persist(bank);
			
			entityTransaction.commit();
		}catch(Exception e) {
			entityTransaction.rollback();
		}finally {
			entityManager.close();
			factory.close();
		}

	}

}
