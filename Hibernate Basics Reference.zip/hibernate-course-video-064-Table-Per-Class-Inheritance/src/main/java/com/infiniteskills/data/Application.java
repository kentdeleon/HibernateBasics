package com.infiniteskills.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.infiniteskills.data.entities.Bond;
import com.infiniteskills.data.entities.Investment;
import com.infiniteskills.data.entities.Portfolio;
import com.infiniteskills.data.entities.Stock;

public class Application {

	public static void main(String[] args) {

		Logger LOGGER = LoggerFactory.getLogger(Application.class);
		SessionFactory sessionFactory = null;
		Session session = null;
		org.hibernate.Transaction tx = null;

		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			Portfolio portfolio = new Portfolio();
			portfolio.setName("Kent Portfolio");

			Stock stock = ApplicationUtil.createStock(new BigDecimal(150.00), 10L, "Double Dragon Stock", "PH Stock",
					new Date());
			Bond bond = ApplicationUtil.createBond(new BigDecimal(100.00), new BigDecimal(0.10), new Date(),
					"Multilink Bonds", "Pru Life", new Date());

			stock.setPortfolio(portfolio);
			bond.setPortfolio(portfolio);
			portfolio.getInvestments().add(stock);
			portfolio.getInvestments().add(bond);

			session.save(portfolio);
			session.save(stock);
			session.save(bond);

			tx.commit();

			Portfolio dbPortfolio = (Portfolio) session.get(Portfolio.class, portfolio.getPortfolioId());
			LOGGER.info("dbPortfolio : " + dbPortfolio.getInvestments().get(0).getName());
			LOGGER.info("dbPortfolio : " + dbPortfolio.getInvestments().get(1).getName());
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			session.close();
			sessionFactory.close();
		}
	}

}
