package com.infiniteskills.data.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="PORTFOLIO")
public class Portfolio {

	@Id
	@GeneratedValue
	@Column(name="PORTFOLIO_ID")
	private Long portfolioId;
	
	@Column(name="NAME")
	private String name;
	
	//mappedBy portfolio in Investment Class
	@OneToMany(mappedBy="portfolio")
	private List<Investment> investments = new ArrayList<>();

	public Long getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Long portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Investment> getInvestments() {
		return investments;
	}

	public void setInvestments(List<Investment> investments) {
		this.investments = investments;
	}
	
	
}
