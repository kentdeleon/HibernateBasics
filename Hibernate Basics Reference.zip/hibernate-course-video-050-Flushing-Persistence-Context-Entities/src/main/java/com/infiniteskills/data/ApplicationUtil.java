package com.infiniteskills.data;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.slf4j.Logger;

import com.infiniteskills.data.entities.Account;
import com.infiniteskills.data.entities.Address;
import com.infiniteskills.data.entities.Bank;
import com.infiniteskills.data.entities.Transaction;
import com.infiniteskills.data.entities.User;

public class ApplicationUtil {

	public final static void runDemoForBiDirectionalManyToMany040(Session session) {

		try {
			org.hibernate.Transaction transaction = session.beginTransaction();

			// creating accounts
			Account octalAccount = ApplicationUtil.createNewAccount("BiDirecitonal Many Many Checking Account",
					"Checking Account", new BigDecimal(15000.00), new BigDecimal(15000.00), new Date(), new Date(),
					"Kent De Leon", new Date(), new Date(), "Kent de Leon");
			Account pccwAccount = ApplicationUtil.createNewAccount("BiDirecitonal Many Many Savings Account",
					"Savings Account", new BigDecimal(15000.00), new BigDecimal(15000.00), new Date(), new Date(),
					"Kent De Leon", new Date(), new Date(), "Kent de Leon");

			// creating address for users
			List<Address> addresses = new ArrayList<>();
			addresses.add(ApplicationUtil.createAddress("Quezon City Timog Ave", "Scout Lozano", "Quezon City", "QC",
					"12345"));

			// creating users and setting the address
			User user = ApplicationUtil.createUser("BiDirectional", "ManyToManyOne", new Date(), "first.name@email.com",
					new Date(), "Kent De Leon", new Date(), "Kent De leon");
			user.setAddress(addresses);
			User user2 = ApplicationUtil.createUser("BiDirectional", "ManyToManyTwo", new Date(), "two.name@email.com",
					new Date(), "Kent De Leon", new Date(), "Kent De leon");
			user2.setAddress(addresses);

			// creating user set and setting the user set to each accounts
			Set<User> userSet = new HashSet<>();
			userSet.add(user);
			userSet.add(user2);
			octalAccount.setUsers(userSet);
			pccwAccount.setUsers(userSet);

			// creating account set and setting the account set to each users
			// saving the accounts
			Set<Account> accountSet = new HashSet<>();
			accountSet.add(octalAccount);
			accountSet.add(pccwAccount);
			user.setAccounts(accountSet);
			user2.setAccounts(accountSet);

			session.save(octalAccount);
			session.save(pccwAccount);

			session.save(user);
			session.save(user2);

			transaction.commit();

			// verifying the account was added
			Account dbAccount = (Account) session.get(Account.class, octalAccount.getAccountId());
			System.out.println("dbAccount: " + dbAccount.getUsers().iterator().next().getEmailAddress());

			User userDb = (User) session.get(User.class, user.getUserId());
			System.out.println("userDb: " + userDb.getAccounts().iterator().next().getName());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}

	public final static void runDemoForSavingEntities_044(Session session) {
		Account account = ApplicationUtil.createNewAccount("Saving Entities Account Part2", "Savings",
				new BigDecimal(1500.00), new BigDecimal(1500.00), new Date(), new Date(), "Kent De Leon", new Date(),
				new Date(), "Kent De Leon");
		Transaction transaction1 = ApplicationUtil.addSingleTransaction("Deposit", "Deposit 100.00",
				new BigDecimal(100.00), new BigDecimal(0.00), new BigDecimal(0.00), "Deposit 100.00", "Kent De Leon",
				new Date(), "Kent De Leon", new Date(), account);

		Transaction transaction2 = ApplicationUtil.addSingleTransaction("Withdraw", "Withdraw 100.00",
				new BigDecimal(100.00), new BigDecimal(0.00), new BigDecimal(0.00), "Withdraw 100.00", "Kent De Leon",
				new Date(), "Kent De Leon", new Date(), account);

		account.getTransaction().add(transaction1);
		account.getTransaction().add(transaction2);

		// transient state
		System.out.println("account: " + session.contains(account));
		System.out.println("transactions1: " + session.contains(transaction1));
		System.out.println("transaction2: " + session.contains(transaction2));

		try {
			org.hibernate.Transaction transaction = session.beginTransaction();
			session.save(account);

			// persistent state
			System.out.println("account: " + session.contains(account));
			System.out.println("transactions1: " + session.contains(transaction1));
			System.out.println("transaction2: " + session.contains(transaction2));

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}

	public final static void runDemoRetrievingEntities_045(Session session, Logger LOGGER) {
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();

			// get method - also reference Object cache in persisting context
			// Bank bank = (Bank) session.get(Bank.class, 1L);
			// bank = (Bank) session.get(Bank.class, 1L);

			// load method - hibernate always attempts to return a proxy
			// Once we need to reference something it is only the time the Database
			// operation will be executed
			Bank bankLoad = (Bank) session.load(Bank.class, 1L);

			LOGGER.info("Method Executed");

			System.out.println(bankLoad.getName());
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}

	public final static void runDemoModifyingEntities_046(Session session) {
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();
			// Get the Bank
			Bank bank = (Bank) session.get(Bank.class, 1L);

			System.out.println("Old Name: " + bank.getName());

			// Set new values
			bank.setName("Second National Trust");
			bank.setLastUpdatedBy("Kent De Leon");
			bank.setLastUpdatedDate(new Date());

			System.out.println("New Name: " + bank.getName());

			// Commit the changes
			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}

	}

	public final static void runDemoRemovingEntities_047(Session session, Logger LOGGER) {
		try {
			org.hibernate.Transaction transaction = session.beginTransaction();

			Bank bank = (Bank) session.get(Bank.class, 1L);
			LOGGER.info("is bank entities still exists? " + session.contains(bank));

			// invoke delete method on the session to delete the entity
			session.delete(bank);

			LOGGER.info("Method Delete Invoked!");
			LOGGER.info("is bank entities still exists? " + session.contains(bank));

			transaction.commit();
		} catch (IllegalArgumentException iae) {
			LOGGER.error("Trying to delete a null entity failed!");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}

	public final static void runDemoReattachingDetachedEntities(Logger LOGGER) {
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			org.hibernate.Transaction transaction = session.beginTransaction();
			Bank bank = (Bank) session.get(Bank.class, 1L);
			transaction.commit();
			session.close();

			Session session2 = HibernateUtil.getSessionFactory().openSession();
			org.hibernate.Transaction transaction2 = session2.beginTransaction();

			LOGGER.info("is bank object exists on session2? " + session2.contains(bank));
			session2.update(bank);
			LOGGER.info("Method Update Invoke!");
			LOGGER.info("is bank object exists on session2? " + session2.contains(bank));
			transaction2.commit();
			session2.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			HibernateUtil.getSessionFactory().close();
		}
	}
	
	public final static void runDemoSaveOrUpdateEntities() {
		try {
			Session session = HibernateUtil.getSessionFactory().openSession();
			org.hibernate.Transaction transaction = session.beginTransaction();
			Bank detachBank = (Bank) session.get(Bank.class, 1L);
			transaction.commit();
			session.close();

			Address transietBankAddress = ApplicationUtil.createAddress("Makati City", "Salcedo Village", "Makati City", "MK", "12345");
			Bank transientBank = ApplicationUtil.createBank("Union Bank", transietBankAddress, false,
					"Kent De Leon", new Date(), "Kent De Leon", new Date(), "PRIMARY");
			
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			org.hibernate.Transaction transaction2 = session2.beginTransaction();
			
			session2.saveOrUpdate(detachBank);
			session2.saveOrUpdate(transientBank);
			detachBank.setName("Test Bank 2");
			
			transaction2.commit();
			session2.close();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			HibernateUtil.getSessionFactory().close();
		}
	}

	
	public final static void runDemoFlushingPersistenceContextEntity(Logger LOGGER) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		org.hibernate.Transaction transaction = session.beginTransaction();
		
		try {
		
			Bank bank = (Bank) session.get(Bank.class, 1L);
			bank.setName("Something Different");
			LOGGER.info("CALLING FLUSH method");
			session.flush();
			
			Address address = bank.getAddress();
			address.setAddressLine1("Another Address line 1");
			bank.setAddress(address);
			LOGGER.info("CALLING commit transaction");
			transaction.commit();
		}catch(Exception e) {
			transaction.rollback();
			e.printStackTrace();
		}finally {
			session.close();
			HibernateUtil.getSessionFactory().close();
		}
	}
	public final static Bank createBank(String name, Address address, boolean isInternational, String lastUpdatedBy,
			Date lastUpdatedDate, String createdBy, Date createdDate, String addressType) {
		return Bank.createBank(name, address, isInternational, lastUpdatedBy, lastUpdatedDate, createdBy, createdDate,
				addressType);
	}

	public final static Address createAddress(String addressLine1, String addressLine2, String city, String state,
			String zipCode) {
		return Address.createAddress(addressLine1, addressLine2, city, state, zipCode);
	}

	public final static User createUser(String firstName, String lastName, Date birthDate, String emailAddress,
			Date lastUpdatedDate, String lastUpdatedBy, Date createDate, String createdBy) {
		return User.createUser(firstName, lastName, birthDate, emailAddress, lastUpdatedDate, lastUpdatedBy, createDate,
				createdBy);
	}

	public final static Account createNewAccount(String name, String accountType, BigDecimal initialBalance,
			BigDecimal currentBalance, Date openDate, Date closeDate, String lastUpdatedBy, Date lastUpdatedDate,
			Date createdDate, String createdBy) {
		Account account = Account.createAccount(name, accountType, initialBalance, currentBalance, openDate, closeDate,
				lastUpdatedBy, lastUpdatedDate, createdDate, createdBy);
		return account;
	}

	public final static Transaction addSingleTransaction(String transactionType, String title, BigDecimal amount,
			BigDecimal initialBalance, BigDecimal closingBalance, String notes, String lastUpdatedBy,
			Date lastUpdatedDate, String createdBy, Date createdDate, Account account) {
		return Transaction.createSingleTransaction(transactionType, title, amount, initialBalance, closingBalance,
				notes, lastUpdatedBy, lastUpdatedDate, createdBy, createdDate, account);
	}

	public final static Transaction addSingleTransaction(String transactionType, String title, BigDecimal amount,
			BigDecimal initialBalance, BigDecimal closingBalance, String notes, String lastUpdatedBy,
			Date lastUpdatedDate, String createdBy, Date createdDate) {
		return Transaction.createSingleTransaction(transactionType, title, amount, initialBalance, closingBalance,
				notes, lastUpdatedBy, lastUpdatedDate, createdBy, createdDate);
	}

	public final static List<Transaction> addTransactions(Account account) {
		List<Transaction> transactions = new ArrayList<>();

		Transaction transactions1 = new Transaction();
		transactions1.setTitle("13th Month Pay");
		transactions1.setAmount(new BigDecimal(500.00));
		transactions1.setClosingBalance(new BigDecimal(0.00));
		transactions1.setCreatedBy("Kent De Leon");
		transactions1.setCreatedDate(new Date());
		transactions1.setInitialBalance(new BigDecimal(0.00));
		transactions1.setTransactionType("Deposit");
		transactions1.setLastUpdatedBy("Kent De Leon");
		transactions1.setLastUpdatedDate(new Date());
		transactions1.setNotes("Depositing 13th Month Pay");
		transactions1.setAccount(account);

		Transaction transactions2 = new Transaction();
		transactions2.setTitle("Purchase Shoes");
		transactions2.setAmount(new BigDecimal(50.00));
		transactions2.setClosingBalance(new BigDecimal(0.00));
		transactions2.setCreatedBy("Kent De Leon");
		transactions2.setCreatedDate(new Date());
		transactions2.setInitialBalance(new BigDecimal(0.00));
		transactions2.setTransactionType("Debit");
		transactions2.setLastUpdatedBy("Kent De Leon");
		transactions2.setLastUpdatedDate(new Date());
		transactions2.setNotes("Purchase Shoes");
		transactions2.setAccount(account);

		transactions.add(transactions1);
		transactions.add(transactions2);

		return transactions;

	}
}
